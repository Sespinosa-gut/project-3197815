<?php include("conexion.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Intercambios</title>
    <link rel="stylesheet" href="gestionar-intercambios.css">
</head>
<body>
<header><h1>Gestión de Intercambios</h1></header>
<main>
    <form method="POST">
        <input type="text" name="ofrecido" placeholder="Producto ofrecido" required>
        <input type="text" name="deseado" placeholder="Producto deseado" required>
        <input type="text" name="proponente" placeholder="Nombre" required>
        <input type="text" name="contacto" placeholder="Contacto" required>
        <input type="date" name="fecha" required>
        <select name="estado">
            <option value="pendiente">Pendiente</option>
            <option value="aceptado">Aceptado</option>
            <option value="rechazado">Rechazado</option>
            <option value="completado">Completado</option>
            <option value="cancelado">Cancelado</option>
        </select>
        <textarea name="notas" placeholder="Notas adicionales"></textarea>
        <button type="submit" name="guardar">Guardar</button>
    </form>

    <?php
    if(isset($_POST['guardar'])){
        $conn->query("INSERT INTO intercambios (ofrecido,deseado,proponente,contacto,fecha,estado,notas)
        VALUES ('{$_POST['ofrecido']}','{$_POST['deseado']}','{$_POST['proponente']}','{$_POST['contacto']}',
        '{$_POST['fecha']}','{$_POST['estado']}','{$_POST['notas']}')");
    }
    ?>

    <h2>Intercambios Registrados</h2>
    <table>
        <tr><th>Ofrecido</th><th>Deseado</th><th>Proponente</th><th>Contacto</th><th>Fecha</th><th>Estado</th><th>Notas</th></tr>
        <?php
        $res = $conn->query("SELECT * FROM intercambios");
        while($row = $res->fetch_assoc()){
            echo "<tr>
                    <td>{$row['ofrecido']}</td>
                    <td>{$row['deseado']}</td>
                    <td>{$row['proponente']}</td>
                    <td>{$row['contacto']}</td>
                    <td>{$row['fecha']}</td>
                    <td>{$row['estado']}</td>
                    <td>{$row['notas']}</td>
                  </tr>";
        }
        ?>
    </table>
</main>
</body>
</html>