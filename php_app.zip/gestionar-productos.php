<?php include("conexion.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Productos</title>
    <link rel="stylesheet" href="gestionar-productos.css">
</head>
<body>
<header>
    <h1>Gestión de Productos</h1>
</header>
<main>
    <section>
        <h2>Agregar Nuevo Producto</h2>
        <form method="POST">
            <input type="text" name="nombre" placeholder="Nombre" required>
            <textarea name="descripcion"></textarea>
            <input type="number" name="cantidad" min="0" required>
            <input type="number" name="precio" step="0.01">
            <input type="text" name="categoria">
            <select name="tipo">
                <option value="intercambio">Intercambio</option>
                <option value="venta">Venta</option>
                <option value="ambos">Ambos</option>
            </select>
            <button type="submit" name="guardar">Guardar</button>
        </form>
    </section>
    <?php
    if(isset($_POST['guardar'])){
        $conn->query("INSERT INTO productos (nombre, descripcion, cantidad, precio, categoria, tipo)
        VALUES ('{$_POST['nombre']}','{$_POST['descripcion']}',{$_POST['cantidad']},{$_POST['precio']},'{$_POST['categoria']}','{$_POST['tipo']}')");
    }
    ?>
    <section>
        <h2>Productos</h2>
        <table>
            <tr><th>Nombre</th><th>Descripción</th><th>Cantidad</th><th>Precio</th><th>Categoría</th><th>Tipo</th></tr>
            <?php
            $res = $conn->query("SELECT * FROM productos");
            while($row = $res->fetch_assoc()){
                echo "<tr>
                        <td>{$row['nombre']}</td>
                        <td>{$row['descripcion']}</td>
                        <td>{$row['cantidad']}</td>
                        <td>{$row['precio']}</td>
                        <td>{$row['categoria']}</td>
                        <td>{$row['tipo']}</td>
                      </tr>";
            }
            ?>
        </table>
    </section>
</main>
</body>
</html>