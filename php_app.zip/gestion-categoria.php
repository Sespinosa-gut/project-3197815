<?php include("conexion.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Categorías</title>
    <link rel="stylesheet" href="gestion-categoria.css">
</head>
<body>
<header><h1>Gestión de Categorías</h1></header>
<main>
    <form method="POST">
        <input type="text" name="nombre" placeholder="Nombre" required>
        <textarea name="descripcion"></textarea>
        <button type="submit" name="guardar">Guardar</button>
    </form>
    <?php
    if(isset($_POST['guardar'])){
        $conn->query("INSERT INTO categorias (nombre, descripcion) VALUES ('{$_POST['nombre']}','{$_POST['descripcion']}')");
    }
    ?>
    <h2>Categorías</h2>
    <table>
        <tr><th>Nombre</th><th>Descripción</th></tr>
        <?php
        $res = $conn->query("SELECT * FROM categorias");
        while($row = $res->fetch_assoc()){
            echo "<tr><td>{$row['nombre']}</td><td>{$row['descripcion']}</td></tr>";
        }
        ?>
    </table>
</main>
</body>
</html>