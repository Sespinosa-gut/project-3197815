<?php include("conexion.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ventas y Facturas</title>
    <link rel="stylesheet" href="gestionar-ventasyfacturas.css">
</head>
<body>
<header><h1>Ventas</h1></header>
<main>
    <form method="POST">
        <input type="text" name="producto" placeholder="Producto" required>
        <input type="number" name="cantidad" min="1" required>
        <input type="number" step="0.01" name="precio_unitario" required>
        <input type="text" name="cliente" placeholder="Cliente" required>
        <input type="date" name="fecha" required>
        <select name="metodo">
            <option value="efectivo">Efectivo</option>
            <option value="tarjeta">Tarjeta</option>
            <option value="transferencia">Transferencia</option>
        </select>
        <button type="submit" name="guardar">Guardar</button>
    </form>
    <?php
    if(isset($_POST['guardar'])){
        $total = $_POST['cantidad'] * $_POST['precio_unitario'];
        $conn->query("INSERT INTO ventas (producto,cantidad,precio_unitario,total,cliente,fecha,metodo)
        VALUES ('{$_POST['producto']}',{$_POST['cantidad']},{$_POST['precio_unitario']},$total,'{$_POST['cliente']}','{$_POST['fecha']}','{$_POST['metodo']}')");
    }
    ?>
    <h2>Historial</h2>
    <table>
        <tr><th>Producto</th><th>Cant</th><th>P.Unit</th><th>Total</th><th>Cliente</th><th>Fecha</th><th>Método</th></tr>
        <?php
        $res = $conn->query("SELECT * FROM ventas");
        while($row = $res->fetch_assoc()){
            echo "<tr><td>{$row['producto']}</td><td>{$row['cantidad']}</td><td>{$row['precio_unitario']}</td><td>{$row['total']}</td><td>{$row['cliente']}</td><td>{$row['fecha']}</td><td>{$row['metodo']}</td></tr>";
        }
        ?>
    </table>
</main>
</body>
</html>