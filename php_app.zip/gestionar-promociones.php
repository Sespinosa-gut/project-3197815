<?php include("conexion.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Promociones</title>
    <link rel="stylesheet" href="gestionar-promociones.css">
</head>
<body>
<header><h1>Promociones</h1></header>
<main>
    <form method="POST">
        <input type="text" name="nombre" placeholder="Nombre" required>
        <select name="tipo">
            <option value="descuento-porcentaje">Descuento (%)</option>
            <option value="descuento-fijo">Descuento Fijo</option>
            <option value="envio-gratis">Envío Gratis</option>
            <option value="2x1">2x1</option>
        </select>
        <input type="text" name="valor" placeholder="Valor/Detalle">
        <input type="date" name="inicio" required>
        <input type="date" name="fin">
        <select name="estado">
            <option value="activa">Activa</option>
            <option value="programada">Programada</option>
            <option value="finalizada">Finalizada</option>
        </select>
        <button type="submit" name="guardar">Guardar</button>
    </form>
    <?php
    if(isset($_POST['guardar'])){
        $conn->query("INSERT INTO promociones (nombre,tipo,valor,inicio,fin,estado)
        VALUES ('{$_POST['nombre']}','{$_POST['tipo']}','{$_POST['valor']}',
        '{$_POST['inicio']}','{$_POST['fin']}','{$_POST['estado']}')");
    }
    ?>
    <h2>Promociones</h2>
    <table>
        <tr><th>Nombre</th><th>Tipo</th><th>Valor</th><th>Inicio</th><th>Fin</th><th>Estado</th></tr>
        <?php
        $res = $conn->query("SELECT * FROM promociones");
        while($row = $res->fetch_assoc()){
            echo "<tr><td>{$row['nombre']}</td><td>{$row['tipo']}</td><td>{$row['valor']}</td><td>{$row['inicio']}</td><td>{$row['fin']}</td><td>{$row['estado']}</td></tr>";
        }
        ?>
    </table>
</main>
</body>
</html>