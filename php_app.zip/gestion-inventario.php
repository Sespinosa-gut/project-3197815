<?php include("conexion.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inventario</title>
    <link rel="stylesheet" href="gestion-inventario.css">
</head>
<body>
<header><h1>Inventario</h1></header>
<main>
    <form method="POST">
        <input type="text" name="nombre" placeholder="Nombre" required>
        <textarea name="descripcion"></textarea>
        <input type="number" name="cantidad" min="0" required>
        <select name="tipo">
            <option value="intercambio">Intercambio</option>
            <option value="venta">Venta</option>
            <option value="ambos">Ambos</option>
        </select>
        <button type="submit" name="guardar">Guardar</button>
    </form>
    <?php
    if(isset($_POST['guardar'])){
        $conn->query("INSERT INTO inventario (nombre, descripcion, cantidad, tipo)
        VALUES ('{$_POST['nombre']}','{$_POST['descripcion']}',{$_POST['cantidad']},'{$_POST['tipo']}')");
    }
    ?>
    <h2>Inventario</h2>
    <table>
        <tr><th>Nombre</th><th>Descripción</th><th>Cantidad</th><th>Tipo</th></tr>
        <?php
        $res = $conn->query("SELECT * FROM inventario");
        while($row = $res->fetch_assoc()){
            echo "<tr><td>{$row['nombre']}</td><td>{$row['descripcion']}</td><td>{$row['cantidad']}</td><td>{$row['tipo']}</td></tr>";
        }
        ?>
    </table>
</main>
</body>
</html>